<?php
    include_once("mysql_connector.php");
    session_start();

    $_SESSION["error"] = array("error_no" => "0000", "error_msj" => "");

    if($_POST["txt_change_new_password"] == $_POST["txt_change_repeat_password"]){
        $mysql_reg_query = null;

        $sql_string = sprintf(
            "call change_user_password('%s', '%s', '%s')",
            $_SESSION["token"],
            $_POST['txt_change_current_password'],
            $_POST['txt_change_new_password']
        );

        if($mysql_reg_query = mysqli_query($mysql_connection, $sql_string)){
            if(mysqli_fetch_assoc($mysql_reg_query)["is_password_changed"] == 1){
                $_SESSION["msj"] = "Se ha cambiado tu contraseña exitosamente.";
            }else{
                $_SESSION["error"]["error_no"] = "0001";
                $_SESSION["error"]["error_msj"] = "La contraseña es incorrecta, por favor vuelva a intentarlo.";
            }
        }else{
            $_SESSION["error"]["error_no"] = "0003";
            $_SESSION["error"]["error_msj"] = "No se pudo cambiar tu contraseña debido a un problema con el servidor.";
        }

        if($mysql_reg_query != null){
            mysqli_free_result($mysql_reg_query);
        }
    }else{
        $_SESSION["error"]["error_no"] = "0002";
        $_SESSION["error"]["error_msj"] = "Las contraseñas no coinciden, por favor vuelva a intentarlo.";
    }

    unset($_POST['txt_change_current_password']);
    unset($_POST['txt_change_new_password']);
    unset($_POST['txt_change_repeat_password']);

    header("location: ".$_SERVER["HTTP_REFERER"]);
    exit();
?>