<?php
    include_once("mysql_connector.php");
    session_start();

    $_SESSION["error"] = array("error_no" => "0000", "error_msj" => "");
    $mysql_reg = null;

    $sql_string = sprintf(
        "call edit_user_phone('%s', '%s')",
        $_SESSION["token"],
        $_POST['txt_edit_phone']
    );

    if($mysql_reg = mysqli_query($mysql_connection, $sql_string)){
        $_SESSION["msj"] = "Se ha cambiado el número de teléfono exitosamente.";
    }else{
        $errno = mysqli_errno($mysql_connection);

        if($errno == "1062"){
            $_SESSION["error"]["error_no"] = $errno;
            $_SESSION["error"]["error_msj"] = "El número de teléfono ya se encuentra registrado, por favor vuelva a intentarlo.";
        }else{
            $_SESSION["error"]["error_no"] = "0003";
            $_SESSION["error"]["error_msj"] = "No se pudo cambiar tu número de teléfono debido a un problema con el servidor.";
        }
    }

    unset($_POST['txt_edit_phone']);

    header("location: ".$_SERVER["HTTP_REFERER"]);
    exit();
?>