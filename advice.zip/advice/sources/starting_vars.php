<?php
    include_once("sources/mysql_connector.php");

    $error = array(
        "error_no" => "0000",
        "error_msj" => ""
    );

    $user_info = array(
        "first_name" => "N/A",
        "last_name" => "N/A",
        "email" => "N/A",
        "user_image_exists" => false
    );

    $msj = "";
    $mysql_query_u = null;
    $on_session = false;

    if(isset($_SESSION["error"]) && ($_SESSION["error"]["error_no"] != "0000")){
        $error["error_no"] = $_SESSION["error"]["error_no"];
        $error["error_msj"] = $_SESSION["error"]["error_msj"];

        unset($_SESSION["error"]);
    }

    if(isset($_SESSION["msj"]) && ($_SESSION["msj"] != "")){
        $msj = $_SESSION["msj"];

        unset($_SESSION["msj"]);
    }

    if(isset($_SESSION["token"]) && ($_SESSION["token"] != "")){
        $sql_string = sprintf("call get_user_info('%s'); ", $_SESSION["token"]).((isset($sql_string)) ? $sql_string : "");
        $on_session = true;
    }

    if(isset($sql_string)){
        if(!mysqli_multi_query($mysql_connection, $sql_string) && ($error["error_msj"] == "")){
            $error["error_no"] = "0003";
            $error["error_msj"] = "No se pudo cargar toda la información debido a un problema con el servidor.";
        }
    }

    if($on_session){
        if($mysql_query_u = mysqli_store_result($mysql_connection)){
            $tuple_u = mysqli_fetch_assoc($mysql_query_u);

            $user_info["first_name"] = utf8_decode($tuple_u["first_name"]);
            $user_info["last_name"] = utf8_decode($tuple_u["last_name"]);
            $user_info["email"] = $tuple_u["email"];

            ($tuple_u["user_image_exists"] == 1) ? $user_info["user_image_exists"] = true : $user_info["user_image_exists"] = false;
            
            mysqli_free_result($mysql_query_u);
        }else{
            $error["error_no"] = "0003";
            $error["error_msj"] = "No se pudo cargar toda la información del usuario debido a un problema con el servidor.";
        }

        mysqli_next_result($mysql_connection);
        mysqli_next_result($mysql_connection);
    }
?>