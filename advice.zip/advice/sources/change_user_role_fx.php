<?php
    include_once("mysql_connector.php");
    session_start();

    $_SESSION["error"] = array("error_no" => "0000", "error_msj" => "");
    $mysql_reg = null;

    $sql_string = sprintf(
        "call change_user_role('%s', '%s')",
        $_SESSION["token"],
        $_POST['sel_change_user_role']
    );

    if($mysql_reg = mysqli_query($mysql_connection, $sql_string)){
        $_SESSION["msj"] = "Se ha cambiado tu rol exitosamente.";
    }else{
        $_SESSION["error"]["error_no"] = "0003";
        $_SESSION["error"]["error_msj"] = "No se pudo cambiar tu rol debido a un problema con el servidor.";
    }

    unset($_POST['sel_change_user_role']);

    header("location: ".$_SERVER["HTTP_REFERER"]);
    exit();
?>