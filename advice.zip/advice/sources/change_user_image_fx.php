<?php
    include_once("mysql_connector.php");
    session_start();

    $_SESSION["error"] = array("error_no" => "0000", "error_msj" => "");

    if(isset($_GET['delete']) && ($_GET['delete'] == 1)){
        $mysql_reg_r = null;

        $sql_string_r = sprintf(
            "call remove_user_image('%s')",
            $_SESSION["token"]
        );

        if($mysql_reg_r = mysqli_query($mysql_connection, $sql_string_r)){
            $_SESSION["msj"] = "Se ha eliminado la imagen de usuario exitosamente.";
        }else{
            $_SESSION["error"]["error_no"] = "0003";
            $_SESSION["error"]["error_msj"] = "No se pudo eliminar la imagen de usuario debido a un problema con el servidor.";
        }
    }else{
        $file = $_FILES["fl_user_image"]["tmp_name"];
        $name = $_FILES["fl_user_image"]["name"];
        $size = $_FILES["fl_user_image"]["size"];
        $type = $_FILES["fl_user_image"]["type"];

        if(($file != "") && ($file != null)){
            $file_stream = fopen($file, "rb");
            $data = fread($file_stream, $size);
            $data = addslashes($data);
            fclose($file_stream);

            $mysql_reg_c = null;

            $sql_string_c = sprintf(
                "call change_user_image('%s', '%s', '%s', '%s', '%s')",
                $_SESSION["token"],
                utf8_encode(str_replace("'", "#1#", $name)),
                $size,
                $type,
                $data
            );

            if($mysql_reg_c = mysqli_query($mysql_connection, $sql_string_c)){
                $_SESSION["msj"] = "Se ha cambiado la imagen de usuario exitosamente.";
            }else{
                $_SESSION["error"]["error_no"] = "0003";
                $_SESSION["error"]["error_msj"] = "No se pudo guardar la imagen de usuario debido a un problema con el servidor.";
            }
        }else{
            $_SESSION["error"]["error_no"] = "0003";
            $_SESSION["error"]["error_msj"] = "No se pudo guardar la imagen. El archivo puede estar dañado o no se subió correctamente.";
        }

        unset($_FILES['fl_user_image']);
    }

    header("location: ".$_SERVER["HTTP_REFERER"]);
    exit();
?>