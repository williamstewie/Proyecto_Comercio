<?php
   session_start();
   include_once("sources/starting_vars.php");

   $sql_string = "select first_name, last_name, phone, email from users where token='".$_SESSION["token"]."' ";
   $mysql_query = mysqli_query($mysql_connection, $sql_string) or die(mysqli_error($mysql_connection));
   $tuple = mysqli_fetch_assoc($mysql_query);

   date_default_timezone_set('America/Costa_Rica');
   $date=date('d/m/y G:i:s');
 
   //Libreria en php para crear documentos .pdf
   require('codigos/fpdf.php');

   
   //Declara herencia entre clases para definir el encabezado
   //y pie de pagina del documento
   class PDF extends FPDF{

      //Cabecera de página
      //Redefine la funcion Header de la clase FPDF
      function Header(){
         //Logo de la empresa
         //1.er par: nombre de la imagen a cargar
         //2.do par: esquina superior izquierda
         //3.er par: ordenada de la esquina superior izquierda
         //4.to par: ancho de la imagen, si no especifica se calcula
         //5.to par: alto de la imagen, si no especifica se calcula
         //5.to par: tipo de imagen (jpg | jpeg | png | gif), sino se calcula
         $this->Image('imagenes/logos/logo.png',10,8,33);
   
         //Declaracion de la fuente 
         $this->SetFont('Arial','B',25);
    
         //Movernos a la derecha
         $this->Cell(80);
    
         //Título
         $this->Cell(20,10,'Advice Solutions',0,0,'C'); 
    
         //Salto de línea
         $this->Ln(20);


      }

      
      //Pie de página
      //Redefine la funcion Footer de la clase FPDF
      function Footer(){
         //Posición: a 1,5 cm del borde inferior
         //Mueve la abscisa actual de regreso al márgen izquierdo y establece la ordenada. 
         //Si el valor pasado es negativo, esta es relativa a la parte inferior de la página. 
         $this->SetY(-15);

         //Arial italic 8
         $this->SetFont('Arial','I',8);

         //Número de página
         //PageNo(): devuelve el número de página actual
         $this->Cell(0,10,'Pagina '.$this->PageNo().'/{nb}',0,0,'C');
      }

           //Tabla simple
   function TablaBasica($encabezado){
      //Cabecera
     foreach($encabezado as $col)
       $this->Cell(40,7,$col,1);
     $this->Ln();
  
   }//fin tabla basica

       //Tabla coloreada
       function TablaColoreada($encabezado){
         //Colores, ancho de línea y fuente en negrita
         $this->SetFillColor(240, 233, 6);
         $this->SetTextColor(255);
         $this->SetDrawColor(0,0,0);
         $this->SetLineWidth(.3);
         $this->SetFont('','B');
      
         //Cabecera
         $ancho=array(20,45,25,25,22,25,30);
         for($i=0;$i<count($encabezado);$i++)
            $this->Cell($ancho[$i],7,$encabezado[$i],1,0,'C',1);
         $this->Ln();
      
         //Restauración de colores y fuentes
         $this->SetFillColor(224,235,255);
         $this->SetTextColor(0);
         $this->SetFont('');
      
         //Datos
         $taxes=0;
         $total=0;
         $suma=0;
         $llena=false;
         for($i=0; $i< count($_SESSION["qty"]); $i++){
           $suma=$_SESSION["price"][$i]*$_SESSION["qty"][$i];
           $taxes=$suma*0.13;
           $total= $taxes+$_SESSION["price"][$i];
           $this->Cell($ancho[0],6,$_SESSION["id_device"][$i],'LR',0,'L',$llena);
           $this->Cell($ancho[1],6,$_SESSION["model"][$i],'LR',0,'L',$llena);
           $this->Cell($ancho[2],6,($_SESSION["brand"][$i]),'LR',0,'R',$llena);
           $this->Cell($ancho[3],6,number_format($_SESSION["price"][$i]),'LR',0,'R',$llena);
           $this->Cell($ancho[4],6,number_format($_SESSION["qty"][$i]),'LR',0,'R',$llena);
           $this->Cell($ancho[5],6,number_format($taxes),'LR',0,'R',$llena);
           $this->Cell($ancho[6],6,number_format($total),'LR',0,'R',$llena);
           
           $this->Ln();
           $llena=!$llena;
         }
  
         $this->Cell(array_sum($ancho),0,'','T');
      }//Fin de tabla coloreada


   }
   
 
   //Creación del objeto de la clase heredada
   $pdf=new PDF();

   //Define un alias para el número total de páginas. Se sustituira en el momento 
   //que el documento se cierre. su valor por defecto {nb}
   $pdf->AliasNbPages();

   //Agrega pagina y define caracteristicas de la fuente
   $pdf->AddPage();


   $pdf->SetFont('Times','B',12);
   $pdf->Ln(15);
   $pdf->Cell(0,6,utf8_decode('Advice Solutions'),0,1);
   $pdf->Cell(0,6,utf8_decode('Cedula Juridica: 1-234-567899'),0,1);
   $pdf->Cell(0,6,utf8_decode('Telefono: 8888-8888'),0,1);
   $pdf->Cell(0,6,utf8_decode('correo: advicesolutions2021@gmail.com'),0,1);
   $pdf->Cell(0,6,utf8_decode('Direccion: Miramar, Puntarenas, Costa Rica'),0,1);
   $pdf->Cell(0,6,utf8_decode('Factura Electronica: 1'),0,1);

   $pdf->SetY(73);
   $pdf->SetX(150);
   $pdf->SetX(150);
   $pdf->SetTextColor(240, 233, 6);
   $pdf->Cell(30,10,utf8_decode('Fecha: '.$date.'' ),0,1);
   $pdf->SetX(160);
   $pdf->SetTextColor(0,0,0);



   $pdf->SetY(75);
   $pdf->Ln(10);
   $pdf->SetFont('Times','B',16);
   $pdf->Cell(190,10,'Informacion del cliente',1,1,'C');
   $pdf->Ln(5);
   $pdf->SetFont('Times','B',12);
   $pdf->Ln(5);


   $pdf->SetFont('Times','B',12);
   $pdf->Cell(0,6,utf8_decode('Cliente: '.$tuple["first_name"].' '.$tuple["last_name"].''),0,1);
   $pdf->Cell(0,6,utf8_decode('Telefono: '.$tuple["phone"].''),0,1);
   $pdf->Cell(0,6,utf8_decode('Mail: '.$tuple["email"].''),0,1);



   $pdf->SetY(125);
   $pdf->Ln(10);
   $pdf->SetFont('Times','B',16);
   $pdf->Cell(190,10,'Detalles del producto y factura',1,1,'C');
   $pdf->Ln(5);
   $pdf->SetFont('Times','B',12);
   $pdf->Ln(5);



    //Títulos de las columnas
    $encabezado=array('Codigo','Modelo','Marca','Precio','Cantidad','IVA','Total');
    
    //Carga de datos
    
    $pdf->SetFont('Arial','',14);


 
    //Genera tabla coloreada
    $pdf->Ln(5);

    $pdf->TablaColoreada($encabezado);


  
    $pdf->SetFont('Times','B',16);
    

    $pdf->Ln(5);
    $pdf->SetFont('Times','B',12);

    $totalfila=0;
    $subtotal=0;
    $impuesto=0;
    $totalfinal=0;
    for($i=0; $i< count($_SESSION["qty"]); $i++){
      $totalfila=$_SESSION["price"][$i]*$_SESSION["qty"][$i];
      $subtotal = $subtotal+$totalfila;

      $impuesto=$subtotal*0.13;
      

    }

    $totalfinal= $impuesto+$subtotal;
    $pdf->Cell(0,6,utf8_decode('Subotal Gravado: '.$subtotal.''),0,1);
    $pdf->Cell(0,6,utf8_decode('Descuento Gravado: 0'),0,1);
    $pdf->Cell(0,6,utf8_decode('Subotal Exento: 0'),0,1);
    $pdf->Cell(0,6,utf8_decode('Descuento Exento: 0'),0,1);
    $pdf->Cell(0,6,utf8_decode('Impuesto: 13%'),0,1);
    $pdf->Cell(0,6,utf8_decode('Total: '.$impuesto.''),0,1);
    $pdf->Cell(0,6,utf8_decode('Otros: 0'),0,1);
    $pdf->Cell(0,6,utf8_decode('Total a pagar: '.$totalfinal.''),0,1);
   

   //Finaliza la construccion del pdf y lo envia al navegador
   $pdf->Output();
   include_once("json.php");
?>
