$(document).ready(function(){
    $('#rename_user_collapse').on('hidden.bs.collapse', function(){
        document.getElementById("rename_user_frm").classList.remove('was-validated');
        document.getElementById("rename_user_frm").reset();
    });

    $('#change_user_role_collapse').on('hidden.bs.collapse', function(){
        document.getElementById("change_user_role_frm").classList.remove('was-validated');
        document.getElementById("change_user_role_frm").reset();
    });

    $('#edit_user_phone_collapse').on('hidden.bs.collapse', function(){
        document.getElementById("edit_user_phone_frm").classList.remove('was-validated');
        document.getElementById("edit_user_phone_frm").reset();
    });

    $('#edit_user_email_collapse').on('hidden.bs.collapse', function(){
        document.getElementById("edit_user_email_frm").classList.remove('was-validated');
        document.getElementById("edit_user_email_frm").reset();
    });

    $('.nav-link').on('shown.bs.tab', function(){
        document.getElementById("change_user_password_frm").classList.remove('was-validated');
        document.getElementById("change_user_password_frm").reset();
        $('.collapse').collapse('hide');
    });
});