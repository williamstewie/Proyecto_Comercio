<?php 

    session_start();
    
    include_once("sources/starting_vars.php");
   

    $sql_string = "insert into invoice (user_token) values('".$_SESSION["token"]."') ";
    $mysql_query = mysqli_query($mysql_connection, $sql_string) or die(mysqli_error($mysql_connection));
    $i=0;
    for ($i=0 ; $i< count($_SESSION["id_device"]) ; $i++){
        $sql_string = "insert into dt_invoice (id_invoice,id_device,qty,taxes,price) 
        values( (select MAX(id)  from invoice where user_token = '".$_SESSION["token"]."'), '".$_SESSION["id_device"][$i]."', '".$_SESSION["qty"][$i]."',13.14,'".$_SESSION["price"][$i]."') ";
        $mysql_query = mysqli_query($mysql_connection, $sql_string) or die(mysqli_error($mysql_connection));
    }
   
    $sql_string = "delete from dt_shop_cart where id_sp = (select MAX(id) from shop_cart where user_token = '".$_SESSION["token"]."')";
    $mysql_query = mysqli_query($mysql_connection, $sql_string) or die(mysqli_error($mysql_connection));
    echo "<script>window.open('factura.php', 'Factura', 'width=700, height=700') </script>";
    echo "<script>location.href='store.php'</script>";
    
   

 
?>