<?php
    session_start();
    
    $sql_string = "select dtsp.id as iddeta,dtsp.qty, dv.price,dv.id as id_device,dv.model,dv.brand, dvi.device_image_data, dvi.device_image_type, dvi.device_image_size from shop_cart sp, dt_shop_cart dtsp, devices dv, devices_images dvi
    where  sp.id = dtsp.id_sp and dv.id=dtsp.id_device and dvi.device=dv.id and sp.user_token='".$_SESSION['token']."' ;";
  
    include_once("sources/starting_vars.php");
    // $mysql_query = mysqli_store_result($mysql_connection);
    $_SESSION["price"] = array();
    $_SESSION["qty"] =array();
    $_SESSION["id_device"] = array();
    $_SESSION["model"] = array();
    $_SESSION["brand"] = array();
    $_SESSION["id_device"] = array();
    
?>

<!DOCTYPE html>

<html lang="en-US">
    <head>
        <?php
            include_once("sources/dependencies.php");
            include_once("sources/scripts_fxs.php");
        ?>



        <link rel="stylesheet" type="text/css" href="lib/datatables/css/dataTables.bootstrap4.css" />
        <link rel="stylesheet" type="text/css" href="css/backgrounds_sty.css" />
        <link rel="stylesheet" type="text/css" href="css/store_sty.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.0/sweetalert2.css" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.0/sweetalert2.js"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script type="text/javascript" src="lib/datatables/js/jquery.dataTables.js"></script>
        <script type="text/javascript" src="lib/datatables/js/dataTables.bootstrap4.js"></script>
        <script type="text/javascript" src="js/store_src.js"></script>

        <title>Carrito de Compras | Advice & Solutions</title>
    </head>

    <body>
        <script
            src="https://www.paypal.com/sdk/js?client-id=ASOkgfMhNFInCwZ5rkQ13yDsMiUghH5mp6Nnw1EqxQL3704HeCrEJsEjn6KF50Yyb1ysviFArvnKxjmE"> // Required. Replace YOUR_CLIENT_ID with your sandbox client ID.
        </script>
        <header>
            <?php include_once("includes/header.inc"); ?>
        </header>

        <main>
            <?php
                if($on_session){
                    include_once("includes/change_user_image_modal.inc");
                }
            ?>

            <div class="container-fluid">
                <div class="row">
                    <div id="top_space" class="col-lg-12"></div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <?php include_once("includes/alerts.inc"); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12 pb-3">
                        <?php
                            if($mysql_query = mysqli_store_result($mysql_connection)){
                                if(mysqli_num_rows($mysql_query) > 0){
                                    echo '
                                    
                                        <table id="tb_devices_list" class="w-100">
                                            <thead>
                                                <tr>
                                                    <th class="pb-2">
                                                        <div class="bg-secondary text-light text-center rounded shadow pt-1 pb-1">
                                                            <h5 class="mb-0">
                                                                <strong>Carrito de Compras</strong>
                                                            </h5>
                                                        </div>
                                                    </th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                    ';
                                    $totallinea=0;
                                    $taxes = 0.13;
                                    $subtotal = 0;
                                    $totalpagar = 0;
                                    $total=0;
                                    $sumaimp=0;
                                    $iva=0;
                                    $subprecio=0;
                                    $device_id=0;
                                  
                                    while($tuple = mysqli_fetch_assoc($mysql_query)){
                                        $subprecio=$tuple["price"] * $tuple["qty"];
                                        $iva=$tuple["price"] * $tuple["qty"]* $taxes;
                                        $totallinea= $subprecio +$iva;
                                
                                    
                                        array_push($_SESSION["price"],$tuple["price"]);

                                        array_push($_SESSION["qty"],$tuple["qty"]);
                                        
                                        array_push($_SESSION["model"],$tuple["model"]);

                                        array_push($_SESSION["brand"],$tuple["brand"]);

                                        array_push($_SESSION["id_device"],$tuple["id_device"]);

                                        echo '
                                            '.$_SESSION["price"][0].'
                                            '.$_SESSION["qty"][0].'
                                            '. $_SESSION["id_device"][0].'
                                            '. $_SESSION["model"][0].'
                                            '. $_SESSION["brand"][0].'
                                                <tr>
                                                    <td class="pb-2">
                                                        <div class="card border-0 shadow">
                                                            <div class="card-body">
                                                                <div class="row text-center">
                                                                    <div class="col-sm-2 device-image">
                                                                    <img id="1" src="data:'.$tuple['device_image_type'].';base64,'.base64_encode($tuple['device_image_data']).'" width="120px" height="120px" class="img-fluid">
                                                                    </div>

                                                                    <div class="col-sm-2 device-pane-1">

                                                                        <h5 class="card-title">
                                                                            <strong>'.$tuple["model"].'</strong>
                                                                           
                                                                        </h5>

                                                                        <span>¢'.number_format($tuple["price"], 2, ',', ' ').'</span>

                                                                       
                                                                        
                                                                    </div>
                                                                    <div class="col-sm-1 device-pane-3">
                                                                        
                                                                        <p>Cantidad</p>
                                                                        <center><span>'.$tuple["qty"].'</span></center>
                                                                      

                                                                    </div>  

                                                                                          
                                                                    <div class="col-sm-2 device-pane-2">
                                                                        
                                                                        <p>Subtotal</p>

                                                                        <span>¢'.$subprecio.'</span>
                                                                        

                                                                    </div>  
                                                                    
                                                                    
                                                                    <div class="col-sm-2 device-pane-2">
                                                                        
                                                                        <p>IVA</p>
                                                                        <span>¢'.$iva.'</span>
                                                                      

                                                                    </div>  

                                                                                             
                                                                    <div class="col-sm-2 device-pane-2">
                                                                        
                                                                        <p>Total</p>
                                                                        <span>¢'.$totallinea.'</span>
                                                                       
                                                                      
                                                                      

                                                                    </div> 
                                                                  
                                                                </div>  
                                                                <button class="btn btn-warning rounded-pill text-white"  onclick="borrar('.$tuple["iddeta"].')" "title="Eliminar"><i class="fas fa-trash-alt"></i></button>
                                                            </div>
                                                            
                                                        </div>
                                                        
                                                    </td>
                                                    
                                                </tr>
                                               
                                        ';
                                       
                                       
                                        $total= $total + $totallinea;
                                        
                                    }
                                  

                                

                                    echo '
                                            </tbody>
                                        </table>

                                            <center>
                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-warning rounded-pill" data-toggle="modal" data-target="#exampleModal">
                                                Comprar
                                            </button>
                                            
                                            <!-- Modal -->
                                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Pagar</h5>
                                                    
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                Tiene que pagar un total de '.$total.' IVAI
                                                <div id="paypal-button-container"></div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    
                                                </div>
                                                </div>
                                            </div>
                                            </div>
                                            <center>
                                    ';
                                }else{
                                    echo '
                                    
                                    ';
                                }
                        
                                mysqli_free_result($mysql_query);
                            }
                          
                        ?>
                    </div>
                    
            
                </div>
            </div>
        </main>

        <footer>
            <?php include_once("includes/footer.inc"); ?>
        </footer>
        
        
        <script>

    

            paypal.Buttons({
               
                createOrder: function(data, actions) {
                // This function sets up the details of the transaction, including the amount and line item details.
                return actions.order.create({
                    purchase_units: [{
                    amount: {
                       
                       value:'500'
                        // value: '<?php echo $total ?>'
                    }
                    }]
                });
                },
                onApprove: function(data, actions) {
                // This function captures the funds from the transaction.
                return actions.order.capture().then(function(details) {
                    console.log(details)

                    // This function shows a transaction success message to your buyer.
                    if (details.status=="COMPLETED"){
                        
                        alert('Transaction completed by ' + details.status);
                      
                        location.href = "prueba.php";
                    }
                  
                  
                });
                }
            }).render('#paypal-button-container');
            //This function displays Smart Payment Buttons on your web page.



        </script>

        <script>
            
            function borrar(x) {
                    Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#7cbc24',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
            if (result.isConfirmed) {
                location.href="borrar.php?id="+x; 
                Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
                )
            }
            })
      }
        </script>

    </body>

 
</html>