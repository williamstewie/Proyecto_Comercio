<?php
    session_start();
    include_once("sources/starting_vars.php");
?>

<!DOCTYPE html>

<html lang="en-US">
    <head>
        <?php
            include_once("sources/dependencies.php");
        ?>

        <link rel="stylesheet" type="text/css" href="css/backgrounds_sty.css" />
        <link rel="stylesheet" type="text/css" href="css/login_signup_sty.css" />

        <title>Ingresar | Advice & Solutions</title>
    </head>

    <body>
        <main>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-4"></div>
                    
                    <div class="col-lg-4 py-4">
                        <div class="card border-0 shadow">
                            <div class="card-body text-center p-4">
                                <div class="text-left">
                                    <a href="index.php" class="text-secondary" title="Volver">
                                        <i class="fas fa-arrow-alt-circle-left fa-2x mr-1"></i>
                                    </a>
                                </div>

                                <img src="assets/images/icons/logo2.png" width="80" alt="A&S logo" class="mb-4" />

                                <h3 class="mb-3">
                                    <strong>Ingreso</strong>
                                </h3>

                                <?php include_once("includes/alerts.inc"); ?>

                                <form action="sources/login_fx.php" method="post" enctype="application/x-www-form-urlencoded" id="login_frm" name="login_frm" class="needs-validation" autocomplete="off">
                                    <div class="form-group text-left">
                                        <div class="input-group w-100 pb-1">
                                            <div class="input-group-prepend border-bottom <?php echo ($error["error_no"] == "0001") ? 'border-danger' : 'border-secondary'; ?> pt-2 px-2">
                                                <i class="fas fa-user <?php echo ($error["error_no"] == "0001") ? 'text-danger' : 'text-secondary'; ?>"></i>
                                            </div>

                                            <input type="text" id="txt_login_username_email" name="txt_login_username_email" class="form-control border-top-0 border-left-0 border-right-0 border-bottom <?php echo ($error["error_no"] == "0001") ? 'border-danger' : 'border-secondary'; ?>" maxlength="100" placeholder="Nombre de usuario o e-Mail" aria-label="Nombre de usuario o e-Mail" aria-describedby="login-username-email-input" required />
                                            <div class="invalid-feedback">Nombre de usuario o e-Mail requerido</div>
                                        </div>
                                    </div>

                                    <div class="form-group text-left">
                                        <div class="input-group w-100 pb-1">
                                            <div class="input-group-prepend border-bottom <?php echo ($error["error_no"] == "0001") ? 'border-danger' : 'border-secondary'; ?> pt-2 px-2">
                                                <i class="fas fa-key <?php echo ($error["error_no"] == "0001") ? 'text-danger' : 'text-secondary'; ?>"></i>
                                            </div>

                                            <input type="password" id="txt_login_password" name="txt_login_password" class="form-control border-top-0 border-left-0 border-right-0 border-bottom <?php echo ($error["error_no"] == "0001") ? 'border-danger' : 'border-secondary'; ?>" maxlength="50" placeholder="Contraseña" aria-label="Contraseña" aria-describedby="login-user-password-input" required />
                                            <div class="invalid-feedback">Contraseña requerida</div>
                                        </div>

                                        <a href="#">
                                            <small class="text-muted">¿Olvidaste tu contraseña?</small>
                                        </a>
                                    </div>

                                    <div class="form-group py-3">
                                        <button type="submit" class="btn btn-dark rounded-pill w-50 mb-3">
                                            <strong>Ingresar</strong>
                                        </button>
                                        
                                        <br />

                                        <a href="signup_frm.php" class="text-secondary">
                                            <strong>Registrarse</strong>
                                        </a>
                                    </div>
                                </form>

                                <small>O ingrese utilizando</small>
                                
                                <div id="social_network_accounts_pane" class="pt-2 pb-4">
                                    <a href="" title="Cuenta de Facebook">
                                        <img src="assets/images/icons/facebook.png" height="32" width="32" alt="Facebook account" />
                                    </a>

                                    <a href="" class="mx-1" title="Cuenta de Twitter">
                                        <img src="assets/images/icons/twitter.png" height="32" width="32" alt="Twitter account" />
                                    </a>

                                    <a href="" title="Cuenta de Google">
                                        <img src="assets/images/icons/google.png" height="32" width="32" alt="Google account" />
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4"></div>
                </div>
            </div>
        </main>
    </body>
</html>